svy_ncbreak_count <- function(data, outcomes, predictor, nest = NULL) {
  
  suppressWarnings({
    suppressMessages({
      
      cross_break <- list()
      
      for (i in seq_along(outcomes)) {
        
        o_var <- outcomes[i]
        by_var <- predictor
        base_name <- paste0("base_size", i)
        nvar <- nest
        
        # Variables required
        vars_to_select <- c(outcomes, by_var, nvar)
        
        df_tmp <- data %>%
          select(all_of(vars_to_select))
        
        # Only filter on nest when supplied
        if (!is.null(nvar)) {
          df_tmp <- df_tmp %>%
            filter(!is.na(.data[[nvar]]))
        }
        
        df_tmp <- df_tmp %>%
          mutate(
            !!base_name := case_when(
              is.na(.data[[by_var]]) ~ NA_character_,
              is.na(.data[[o_var]]) ~ NA_character_,
              TRUE ~ "Unweighted bases"
            )
          )
        
        var_label(df_tmp[["variables"]][[base_name]]) <- ""
        
        # Function containing the table common to both versions
        make_table <- function(x) {
          
          x %>%
            tbl_svysummary(
              include = all_of(c(o_var, base_name)),
              by = .data[[by_var]],
              missing = "no",
              statistic = list(
                all_categorical() ~ "{n}",
                base_name ~ "{n_unweighted}"
              ),
              digits = list(all_categorical() ~ 0)
            ) %>%
            add_stat_label(
              label = {{ base_name }} ~ "",
              location = "column"
            ) %>%
            add_overall(last = TRUE) %>%
            modify_header(
              all_stat_cols() ~ "**{level}**",
              label ~ "**Variable**",
              stat_0 ~ "**Total**",
              stat_label ~ ""
            ) %>%
            bold_labels() %>%
            add_p(include = !all_of(base_name)) %>%
            modify_footnote(all_stat_cols() ~ NA)
        }
        
        # Nested vs non-nested
        if (!is.null(nvar)) {
          
          perc <- df_tmp %>%
            tbl_strata(
              strata = all_of(nvar),
              ~ make_table(.x),
              .header = "**{strata}**, N = {n_unweighted}"
            )
          
        } else {
          
          perc <- make_table(df_tmp)
          
        }
        
        perc <- perc %>%
          modify_table_body(
            ~ .x %>%
              dplyr::mutate(
                label = case_when(
                  label == o_var ~ var_label(data[["variables"]][[o_var]]),
                  label == base_name ~ " ",
                  TRUE ~ label
                )
              )
          )
        
        cross_break[[i]] <- perc
      }
      
      table <- cross_break %>%
        tbl_stack() %>%
        modify_column_hide(
          contains("stat_label_") & !contains("stat_label_1")
        )
      
      # Caption depends on whether nested
      if (!is.null(nest)) {
        
        table <- table %>%
          modify_caption(
            paste0(
              "<div style='text-align: left; font-weight: bold; color: black'>",
              "Crosstabulation by ",
              var_label(data[["variables"]][[predictor]]),
              ", nested by ",
              var_label(data[["variables"]][[nest]]),
              ".</div>"
            )
          )
        
      } else {
        
        table <- table %>%
          modify_caption(
            paste0(
              "<div style='text-align: left; font-weight: bold; color: black'>",
              "Crosstabulation by ",
              var_label(data[["variables"]][[predictor]]),
              ".</div>"
            )
          )
      }
      
    })
  })
  
  return(table)
}