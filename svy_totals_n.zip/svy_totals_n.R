svy_totals_n <- function(data, variables, caption = NULL) {
  
  if (is.null(caption)) {
    caption <- "Weighted counts"
  }
  
  table <- data %>%
    tbl_svysummary(
      include = all_of(variables),
      missing = "no",
      statistic = list(
        all_categorical() ~ "{n}"
      ),
      digits = list(
        all_categorical() ~ 0
      )
    ) %>%
    modify_header(
      all_stat_cols() ~ "**{level}**",
      label ~ "**Variable**"
    ) %>%
    bold_labels() %>%
    modify_caption(
      paste0(
        "<div style='text-align: left; font-weight: bold; color: black'>",
        caption,
        "</div>"
      )
    ) %>%
    add_n(
      statistic = "{N_nonmiss_unweighted}",
      last = TRUE
    ) %>%
    modify_footnote(
      all_stat_cols() ~ 
        "Weighted counts. Unweighted base size shown in column N"
    )
  
  return(table)
}