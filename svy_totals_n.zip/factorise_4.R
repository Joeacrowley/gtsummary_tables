factorise_4 <- function(var){
  
  # Capture variable label before any transformation
  var_label <- attributes(var)$label
  
  spss_value_labels_all <- (attributes(var)$labels)
  
  valid_values <- names(table(var))
  spss_value_labels_present <- spss_value_labels_all[spss_value_labels_all %in% valid_values]
  
  if(is.null(spss_value_labels_present)) {
    spss_value_labels_present <- valid_values
    names(spss_value_labels_present) <- valid_values
  }
  
  var_2 <- case_when(var %in% spss_value_labels_present ~ names(spss_value_labels_present)[match(var, spss_value_labels_present)], 
                     is.na(var) ~ NA, 
                     TRUE ~ as.character(var))
  
  var_levels <- unique(c(names(spss_value_labels_present), valid_values))
  var_2 <- factor(var_2, levels = var_levels)
  var_2 <- droplevels(var_2)
  
  valid_values_with_no_cases <- setdiff(spss_value_labels_all[spss_value_labels_all >= 0], var_levels)
  
  if(length(valid_values_with_no_cases) > 0){ 
    present_levels <- levels(var_2)
    var_levels_restore <- names(spss_value_labels_all)[match(valid_values_with_no_cases, spss_value_labels_all)]
    new_levels <- c(present_levels, var_levels_restore)
    new_levels_arranged <- intersect(names(spss_value_labels_all), new_levels)
    var_2 <- factor(var_2, levels = new_levels_arranged)
  }
  
  # Restore variable label
  attr(var_2, "label") <- var_label
  
  return(var_2)
  
}