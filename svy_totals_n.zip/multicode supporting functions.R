bases_equal <- function(
    df, # data frame
    vars # character vector of variables
    ) {
  
  unique_base_sizes <- 
  df %>% 
  select(all_of(vars)) %>% 
  map_int(., ~sum(is.na(.x))) %>% 
  unique()

unique_base_sizes

result <- length(unique_base_sizes) == 1

return(result)

}


splitter_present <- function(
    df, 
    vars) { 
  
  labels_contain_splitter <- 
    df %>% 
    select(all_of(vars)) %>%
    var_label(unlist = T, null_action = "fill") %>% 
    map_int(., ~str_count(.x, ": "))

  labels_contain_splitter
  
  # Check each label contains the splitter, returns TRUE if they do
  all_contain_splitter <- length(labels_contain_splitter) == sum(labels_contain_splitter)
  
  # Check no label contains the splitter more than once, returns TRUE all equal 1
  splitter_appears_once_each <- max(labels_contain_splitter) == 1
  
  # result is TRUE if both statements equal true. 
  result <- all_contain_splitter == TRUE & splitter_appears_once_each == TRUE
  return(result)

}


# As a function - returns relabelled data frame... 
revise_labels <- function(
    df, # data frame
    vars # character vector of variable names
    ) {
  
  # Create a list containing the revised variables
  revised_labels_as_list <- 
    map(vars, function(xxx) { 
    variable_label <- df %>% select(all_of(xxx)) %>% var_label %>% str_split_i(., ": ", 2)
    return(variable_label)
  }) 
  names(revised_labels_as_list) <- vars # add names

  # Revise variable labels
  var_label(df) <- revised_labels_as_list
  return(df)
  
}