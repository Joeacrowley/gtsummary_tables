svy_cbreak_interim_paired <- function (data, outcome, crossbreak, paired_id, ci = FALSE, caption = NULL) 
{
  if(is.null(caption)){
    caption <- "Weighted percentages"
  } 
  
  caption <- paste0("<div style='text-align: left; font-weight: bold; color: black'>", caption,"</div>")
  
  cross_break <- list()
  for (i in 1:length(outcome)) {
    o_var <- outcome[i]
    by_var <- crossbreak
    base_name <- paste0("base_size", i)
    
    # Mutate directly on the tbl_svy object
    data <- data %>%
      mutate(`:=`(!!base_name, case_when(
        is.na(.data[[by_var]]) ~ NA,
        is.na(.data[[o_var]])  ~ NA,
        TRUE ~ "Unweighted bases"
      )))
    var_label(data$variables[[base_name]]) <- ""
    
    # Compute paired p-value from underlying data frame
    raw_data <- as.data.frame(data) %>%
      select(all_of(c(o_var, by_var, paired_id))) %>%
      filter(!is.na(.data[[o_var]]), !is.na(.data[[by_var]])) %>%
      pivot_wider(
        id_cols     = all_of(paired_id),
        names_from  = all_of(by_var),
        values_from = all_of(o_var)
      )
    
    wave_cols <- setdiff(names(raw_data), paired_id)
    
    if (length(wave_cols) == 2 && is.numeric(raw_data[[wave_cols[1]]])) {
      paired_test <- t.test(
        raw_data[[wave_cols[1]]],
        raw_data[[wave_cols[2]]],
        paired = TRUE
      )
      p_val <- paired_test$p.value
    } else {
      tbl <- table(raw_data[[wave_cols[1]]], raw_data[[wave_cols[2]]])
      p_val <- mcnemar.test(tbl)$p.value
    }
    
    p_formatted <- style_pvalue(p_val)
    
    perc_break <- data %>% 
      filter(!is.na(.data[[by_var]])) %>%
      tbl_svysummary(include = all_of(c(o_var, base_name)), 
                     by = all_of(by_var), missing = "no", 
                     statistic = list(all_categorical() ~ "{p}", 
                                      base_name ~ "{n_unweighted}"), 
                     digits = list(all_categorical() ~ 0)) %>% 
      modify_header(all_stat_cols() ~ "**{level}**", label ~ "**Variable**") %>% 
      bold_labels() %>%
      modify_table_body(
        ~ .x %>% mutate(p.value = ifelse(variable == o_var & row_type == "label",
                                         p_formatted, NA_character_))
      ) %>%
      modify_header(p.value ~ "**p-value**")
    
    perc_total <- data %>% 
      tbl_svysummary(include = all_of(c(o_var, base_name)), 
                     missing = "no", 
                     statistic = list(all_categorical() ~ "{p}", 
                                      base_name ~ "{n_unweighted}"), 
                     digits = list(all_categorical() ~ 0)) %>% 
      add_stat_label(label = {{base_name}} ~ "", location = "column") %>% 
      modify_header(all_stat_cols() ~ "**{level}**", label ~ "**Variable**", 
                    stat_0 ~ "**Total**", stat_label ~ "") %>% 
      bold_labels()
    
    if (ci == TRUE) {
      perc_total <- perc_total %>% add_ci(include = -base_name, 
                                          statistic = list(all_categorical() ~ "[{conf.low} - {conf.high}]"), 
                                          style_fun = all_categorical() ~ label_style_sigfig(scale = 100, digits = 1))
      perc_break <- perc_break %>% add_ci(include = -base_name, 
                                          statistic = list(all_categorical() ~ "[{conf.low} - {conf.high}]"), 
                                          style_fun = all_categorical() ~ label_style_sigfig(scale = 100, digits = 1))
    }
    
    perc <- tbl_merge(list(perc_total, perc_break), tab_spanner = F)
    cross_break[[i]] <- perc
  }
  
  table <- cross_break %>% tbl_stack() %>% modify_caption(caption) %>% 
    modify_footnote(all_stat_cols() ~ "Weighted percentages. Unweighted base sizes shown below each table. P-values from paired t-test (continuous) or McNemar's test (categorical).") %>% 
    modify_spanning_header(all_stat_cols() ~ paste0("**", var_label(data$variables[[by_var]]), "**"), 
                           starts_with("ci_stat") ~ paste0("**", var_label(data$variables[[by_var]]), "**"), 
                           ends_with("_0") ~ NA)
  return(table)
}

svy_cbreaks_paired <- function (data, outcomes, crossbreaks, paired_id, ci = FALSE, caption = NULL) 
{
  pid <- paired_id
  
  tables_int <- map(crossbreaks, function(cb) {
    svy_cbreak_interim_paired(
      data       = data,
      outcome    = outcomes, 
      crossbreak = cb, 
      paired_id  = pid,
      ci         = ci, 
      caption    = caption
    )
  })
  
  if (length(tables_int) > 1) {
    for (i in 2:length(tables_int)) {
      tables_int[[i]] <- tables_int[[i]] %>% modify_table_body(~.x %>% 
                                                                 select(!contains("stat_0")) %>% select(!contains("stat_label")))
    }
  }
  
  variable_labels <- data$variables %>% select(all_of(crossbreaks)) %>% 
    var_label(unlist = T) %>% paste0("**", ., "**")
  
  tables <- tbl_merge(tables_int, tab_spanner = variable_labels) %>% 
    modify_spanning_header(contains("stat_label") ~ NA, contains("stat_0") ~ NA)
  
  return(tables)
}
